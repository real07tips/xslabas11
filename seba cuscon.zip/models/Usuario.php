<?php

class Usuario {
    private $id;
    private $email;
    private $nombre;
    private $contrasena;

    public function __construct($email, $nombre, $contrasena, $id = null) {
        $this->id = $id;
        $this->email = $email;
        $this->nombre = $nombre;
        $this->contrasena = $contrasena;
    }

    public function getId() { return $this->id; }
    public function getEmail() { return $this->email; }
    public function getNombre() { return $this->nombre; }
    public function getContrasena() { return $this->contrasena; }

    public static function listar($pdo) {
        $stmt = $pdo->prepare('SELECT * FROM usuarios ORDER BY nombre');
        $stmt->execute();

        $usuarios = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $usuarios[] = new Usuario(
                $f['email'],
                $f['nombre'],
                $f['contrasena'],
                $f['id']
            );
        }

        return $usuarios;
    }

    public static function buscarPorId($pdo, $id) {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = ?');
        $stmt->execute([(int)$id]);
        $f = $stmt->fetch(PDO::FETCH_ASSOC);

        return $f ? new Usuario(
            $f['email'],
            $f['nombre'],
            $f['contrasena'],
            $f['id']
        ) : null;
    }

    public static function crear($pdo, $email, $nombre, $contrasena) {
        $stmt = $pdo->prepare(
            'INSERT INTO usuarios (email, nombre, contrasena) VALUES (?, ?, ?)'
        );
        return $stmt->execute([$email, $nombre, $contrasena]);
    }

    public static function actualizar($pdo, $id, $email, $nombre, $contrasena) {
        $stmt = $pdo->prepare(
            'UPDATE usuarios SET email = ?, nombre = ?, contrasena = ? WHERE id = ?'
        );
        return $stmt->execute([$email, $nombre, $contrasena, (int)$id]);
    }

    public static function eliminar($pdo, $id) {
        $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id = ?');
        return $stmt->execute([(int)$id]);
    }
}
