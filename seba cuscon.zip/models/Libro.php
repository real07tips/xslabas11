<?php
// models/Libro.php

class Libro {
    private $id;
    private $titulo;
    private $autor;
    private $genero;
    private $stock;
    private $imagen;

    public function __construct($id, $titulo, $autor, $genero, $stock, $imagen) {
        $this->id = $id;
        $this->titulo = $titulo;
        $this->autor = $autor;
        $this->genero = $genero;
        $this->stock = $stock;
        $this->imagen = $imagen;
    }

    // --- getters ---
    public function getId() { return $this->id; }
    public function getTitulo() { return $this->titulo; }
    public function getAutor() { return $this->autor; }
    public function getGenero() { return $this->genero; }
    public function getStock() { return (int)$this->stock; }
    public function getImagen() { return $this->imagen; }

    private static function desdeFila($f) {
        return new Libro(
            $f['id'],
            $f['titulo'],
            $f['autor'],
            $f['genero'],
            $f['stock'],
            $f['imagen']
        );
    }

    // --- acceso a datos ---

    public static function listar($pdo) {
        $stmt = $pdo->prepare("SELECT * FROM libros ORDER BY titulo");
        $stmt->execute();

        $libros = [];
        foreach ($stmt->fetchAll() as $f) {
            $libros[] = self::desdeFila($f);
        }
        return $libros;
    }

    public static function buscarPorId($pdo, $id) {
        $stmt = $pdo->prepare("SELECT * FROM libros WHERE id = ?");
        $stmt->execute([$id]);
        $f = $stmt->fetch();
        return $f ? self::desdeFila($f) : null;
    }

    public static function crear($pdo, $titulo, $autor, $genero, $stock, $imagen) {
        $stmt = $pdo->prepare(
            "INSERT INTO libros (titulo, autor, genero, stock, imagen) VALUES (?, ?, ?, ?, ?)"
        );
        return $stmt->execute([$titulo, $autor, $genero, $stock, $imagen]);
    }

    public static function actualizar($pdo, $id, $titulo, $autor, $genero, $stock, $imagen) {
        $stmt = $pdo->prepare(
            "UPDATE libros SET titulo = ?, autor = ?, genero = ?, stock = ?, imagen = ? WHERE id = ?"
        );
        return $stmt->execute([$titulo, $autor, $genero, $stock, $imagen, $id]);
    }

    public static function eliminar($pdo, $id) {
        $stmt = $pdo->prepare("DELETE FROM libros WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
