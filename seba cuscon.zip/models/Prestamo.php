<?php
require_once __DIR__ . '/../conexion.php';

class Prestamo {
    private $id;
    private $socioId;
    private $libroId;
    private $fechaPrestamo;
    private $socioNombre;
    private $libroTitulo;

    public function __construct($id, $socioId, $libroId, $fechaPrestamo, $socioNombre, $libroTitulo) {
        $this->id = $id;
        $this->socioId = $socioId;
        $this->libroId = $libroId;
        $this->fechaPrestamo = $fechaPrestamo;
        $this->socioNombre = $socioNombre;
        $this->libroTitulo = $libroTitulo;
    }

    public function getId() { return $this->id; }
    public function getSocioId() { return $this->socioId; }
    public function getLibroId() { return $this->libroId; }
    public function getFechaPrestamo() { return $this->fechaPrestamo; }
    public function getSocioNombre() { return $this->socioNombre; }
    public function getLibroTitulo() { return $this->libroTitulo; }


public static function listar($pdo) {
        $stmt = $pdo->prepare("
            SELECT p.id, p.socioId, p.libroId, p.fechaPrestamo,
                   s.nombre AS socioNombre,
                   l.titulo AS libroTitulo
            FROM prestamos p
            INNER JOIN socios s ON p.socioId = s.id
            INNER JOIN libros l ON p.libroId = l.id
            ORDER BY p.fechaPrestamo DESC
            ");
        $stmt->execute();

        $prestamo = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $f) {
            $prestamo[] = new Prestamo(
                $f['id'],
                $f['socioId'],
                $f['libroId'],
                $f['fechaPrestamo'],
                $f['socioNombre'],
                $f['libroTitulo']
            );
        }

        return $prestamo;

 }

 public static function crear($pdo, $socioId, $libroId, $fechaPrestamo) {
        // Comprobamos los IDs reales que se van a guardar. Esto evita que
        // un valor inexistente llegue a la clave foránea de prestamos.
        $stmtSocio = $pdo->prepare('SELECT id FROM socios WHERE id = ?');
        $stmtSocio->execute([(int)$socioId]);
        if (!$stmtSocio->fetch(PDO::FETCH_ASSOC)) {
            throw new InvalidArgumentException('El socio seleccionado no existe en la base de datos.');
        }

        $stmtLibro = $pdo->prepare('SELECT id FROM libros WHERE id = ?');
        $stmtLibro->execute([(int)$libroId]);
        if (!$stmtLibro->fetch(PDO::FETCH_ASSOC)) {
            throw new InvalidArgumentException('El libro seleccionado no existe en la base de datos.');
        }

        $stmt = $pdo->prepare(
            'INSERT INTO prestamos (socioId, libroId, fechaPrestamo) VALUES (?, ?, ?)'
        );
        return $stmt->execute([(int)$socioId, (int)$libroId, $fechaPrestamo]);
    }

    public static function buscar($pdo, $id) {
        $stmt = $pdo->prepare("
            SELECT p.id, p.socioId, p.libroId, p.fechaPrestamo,
                   s.nombre AS socioNombre, l.titulo AS libroTitulo
            FROM prestamos p
            INNER JOIN socios s ON p.socioId = s.id
            INNER JOIN libros l ON p.libroId = l.id
            WHERE p.id = ?
        ");
        $stmt->execute([$id]);
        $f = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$f) return null;
        return new Prestamo($f['id'], $f['socioId'], $f['libroId'], $f['fechaPrestamo'], $f['socioNombre'], $f['libroTitulo']);
    }

    public static function editar($pdo, $id, $socioId, $libroId, $fechaPrestamo) {
        $stmt = $pdo->prepare('UPDATE prestamos SET socioId = ?, libroId = ?, fechaPrestamo = ? WHERE id = ?');
        return $stmt->execute([$socioId, $libroId, $fechaPrestamo, $id]);
    }

    public static function eliminar($pdo, $id) {
        $stmt = $pdo->prepare("DELETE FROM prestamos WHERE id = ?");
        return $stmt->execute([$id]);
    }
}