<?php require __DIR__ . '/../header.php'; ?>

<h1 class="h3 mb-3"><?= isset($libro) ? 'Editar libro' : 'Nuevo libro' ?></h1>

<?php
// Géneros sugeridos. El campo también acepta cualquier otro género escrito a mano.
$generosSugeridos = ['Novela', 'Cuento', 'Poesía', 'Teatro', 'Ensayo', 'Ciencia ficción',
                     'Fantasía', 'Terror', 'Misterio', 'Policial', 'Romance', 'Aventura',
                     'Histórico', 'Biografía', 'Infantil', 'Juvenil', 'Ciencia', 'Técnico', 'Otro'];

// Si hubo un error de validación se conserva lo que el usuario escribió.
$valorGenero = $_POST['genero'] ?? (isset($libro) ? $libro->getGenero() : '');
$valorStock  = $_POST['stock']  ?? (isset($libro) ? $libro->getStock()  : 1);
?>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($libro) ? 'editar' : 'crear' ?>"
      enctype="multipart/form-data"
      class="col-md-6">

  <?php if (isset($libro)): ?>
    <input type="hidden" name="id" value="<?= (int)$libro->getId() ?>">
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">Título</label>
    <input type="text" name="titulo" class="form-control"
           value="<?= isset($libro) ? htmlspecialchars($libro->getTitulo()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Autor</label>
    <input type="text" name="autor" class="form-control"
           value="<?= isset($libro) ? htmlspecialchars($libro->getAutor()) : '' ?>" required>
  </div>

  <div class="row">
    <div class="col-md-8 mb-3">
      <label class="form-label">Género</label>
      <input type="text" name="genero" class="form-control" list="lista-generos"
             maxlength="100" value="<?= htmlspecialchars($valorGenero) ?>"
             placeholder="Elegí uno o escribí otro" required>
      <datalist id="lista-generos">
        <?php foreach ($generosSugeridos as $g): ?>
          <option value="<?= htmlspecialchars($g) ?>">
        <?php endforeach; ?>
      </datalist>
    </div>

    <div class="col-md-4 mb-3">
      <label class="form-label">Stock</label>
      <input type="number" name="stock" class="form-control" min="0" step="1"
             value="<?= (int)$valorStock ?>" required>
    </div>
  </div>

  <?php if (isset($libro)): ?>
    <div class="mb-2">
      <label class="form-label d-block">Portada actual</label>
      <?php if ($libro->getImagen()): ?>
        <img src="img/portadas/<?= htmlspecialchars($libro->getImagen()) ?>"
             width="100" class="rounded mb-2" alt="Portada actual">
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">
      <?= isset($libro) ? 'Reemplazar portada (opcional)' : 'Portada (opcional)' ?>
    </label>
    <input type="file" name="imagen" class="form-control" accept="image/*">
    <div class="form-text">JPG, JPEG, PNG, GIF o WEBP. Máximo 2 MB.</div>
  </div>

  <button type="submit" class="btn btn-primary">Guardar</button>
  <a href="index.php?accion=listar" class="btn btn-link">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>
