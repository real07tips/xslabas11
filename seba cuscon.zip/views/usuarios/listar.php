<?php require __DIR__ . '/../header.php'; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 mb-0">Usuarios</h1>
  <a href="index.php?accion=formCrearUsuario" class="btn btn-primary">+ Nuevo Usuario</a>
</div>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if (empty($usuarios)): ?>
  <p class="text-muted">Todavía no hay usuarios cargados.</p>
<?php else: ?>
  <table class="table align-middle">
    <thead>
      <tr>
        <th>Email</th>
        <th>Nombre</th>
        <th class="text-end">Acciones</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($usuarios as $usuario): ?>
      <tr>
        <td><?= htmlspecialchars($usuario->getEmail()) ?></td>
        <td><?= htmlspecialchars($usuario->getNombre()) ?></td>

        <td class="text-end">
          <a href="index.php?accion=formEditarUsuario&id=<?= (int)$usuario->getId() ?>" class="btn btn-sm btn-outline-secondary">Editar</a>
          <a href="index.php?accion=eliminarUsuario&id=<?= (int)$usuario->getId() ?>"
             class="btn btn-sm btn-outline-danger"
             onclick="return confirm('¿Eliminar este usuario?');">Eliminar</a>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>

<?php require __DIR__ . '/../footer.php'; ?>
