<?php require __DIR__ . '/../header.php'; ?>

<h1 class="h3 mb-3"><?= isset($usuario) ? 'Editar usuario' : 'Nuevo usuario' ?></h1>

<?php if (isset($error)): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST"
      action="index.php?accion=<?= isset($usuario) ? 'editarUsuario' : 'crearUsuario' ?>"
      class="col-md-6">

  <?php if (isset($usuario)): ?>
    <input type="hidden" name="id" value="<?= (int)$usuario->getId() ?>">
  <?php endif; ?>

  <div class="mb-3">
    <label class="form-label">Email</label>
    <input type="text" name="email" class="form-control"
           value="<?= isset($usuario) ? htmlspecialchars($usuario->getEmail()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Nombre</label>
    <input type="text" name="nombre" class="form-control"
           value="<?= isset($usuario) ? htmlspecialchars($usuario->getNombre()) : '' ?>" required>
  </div>

  <div class="mb-3">
    <label class="form-label">Contraseña</label>
    <input type="text" name="contraseña" class="form-control"
           value="<?= isset($usuario) ? htmlspecialchars($usuario->getContrasena()) : '' ?>" required>
  </div>

  <button type="submit" class="btn btn-primary"><?= isset($usuario) ? 'Actualizar' : 'Guardar' ?></button>
  <a href="index.php?accion=listarUsuarios" class="btn btn-link">Cancelar</a>
</form>

<?php require __DIR__ . '/../footer.php'; ?>
