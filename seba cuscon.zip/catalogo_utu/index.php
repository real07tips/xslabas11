<?php
require_once __DIR__ . '/../conexion.php';
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#064f91">
  <meta name="description" content="Catálogo digital de la Biblioteca Institucional de UTU">
  <link rel="manifest" href="manifest.json">
  <link rel="icon" href="assets/img/logo-xaread.png">
  <link rel="stylesheet" href="assets/css/app.css">
  <title>Biblioteca UTU · Catálogo</title>
</head>
<body>
<header class="topbar">
  <div class="brand">
    <img src="assets/img/logo-xaread.png" alt="Logo XAREAD">
    <div>
      <span class="eyebrow">Biblioteca Institucional</span>
      <h1>XAREAD · Catálogo</h1>
    </div>
  </div>
  <span class="status-dot">Prototipo complementario</span>
</header>

<main class="container">
  <section class="hero">
    <div>
      <span class="kicker">Explorá la biblioteca</span>
      <h2>Encontrá un libro de forma rápida y sencilla.</h2>
      <p>Buscá por título, autor, género o describí lo que necesitás con lenguaje natural.</p>
    </div>
    <div class="hero-mark">XAREAD</div>
  </section>

  <section class="smart-search card">
    <div class="section-title">
      <div>
        <span class="kicker">Búsqueda inteligente</span>
        <h2>¿Qué estás buscando?</h2>
      </div>
      <span class="ai-badge">Lenguaje natural</span>
    </div>
    <form id="smartForm">
      <div class="search-row">
        <input id="smartQuery" autocomplete="off"
          placeholder="Ej.: libros de ciencia disponibles, o algo de Gabriel García Márquez">
        <button class="btn btn-primary" type="submit">Buscar</button>
      </div>
      <div class="chips">
        <button type="button" class="chip" data-query="libros disponibles">Disponibles</button>
        <button type="button" class="chip" data-query="1984">Buscar 1984</button>
        <button type="button" class="chip" data-query="de Gabriel García Márquez">Por autor</button>
      </div>
      <p id="smartHelp" class="helper">La búsqueda inteligente interpreta términos de disponibilidad, género, autor y título usando únicamente los datos de la base.</p>
    </form>
  </section>

  <section class="filters card">
    <div class="filter-head">
      <div>
        <span class="kicker">Catálogo</span>
        <h2>Todos los libros</h2>
      </div>
      <span id="resultCount" class="count">Cargando…</span>
    </div>
    <div class="filter-grid">
      <label>
        <span>Buscar</span>
        <input id="search" placeholder="Título, autor o palabra clave">
      </label>
      <label>
        <span>Género</span>
        <select id="genre"><option value="">Todos los géneros</option></select>
      </label>
      <label>
        <span>Disponibilidad</span>
        <select id="availability">
          <option value="">Todas</option>
          <option value="available">Disponibles</option>
          <option value="unavailable">No disponibles</option>
        </select>
      </label>
      <button id="clearFilters" class="btn btn-light" type="button">Limpiar filtros</button>
    </div>
  </section>

  <section id="catalog" class="book-grid" aria-live="polite"></section>
  <div id="empty" class="empty card" hidden>
    <div class="empty-icon">⌕</div>
    <h3>No encontramos resultados</h3>
    <p>Probá con otro título, autor, género o término de búsqueda.</p>
  </div>
</main>

<footer>
  <div>Biblioteca Institucional de UTU · Prototipo académico</div>
  <div>Lectura de datos · No modifica el sistema original</div>
</footer>

<div id="modal" class="modal" hidden>
  <div class="modal-backdrop" data-close></div>
  <article class="modal-card">
    <button class="modal-close" data-close aria-label="Cerrar">×</button>
    <div id="modalContent"></div>
  </article>
</div>

<script src="assets/js/app.js"></script>
<script>
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
</script>
</body>
</html>
