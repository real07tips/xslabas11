<?php
// controllers/SocioController.php

require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../conexion.php';

function listarUsuarios() {
    global $pdo;
    $usuarios = Usuario::listar($pdo);
    require __DIR__ . '/../views/usuarios/listar.php';
}

function formCrearUsuario() {
    require __DIR__ . '/../views/usuarios/form.php';
}

function crearUsuario() {
    global $pdo;

    $email = trim($_POST['email'] ?? '');
    $nombre    = trim($_POST['nombre'] ?? '');
    $contraseña   = trim($_POST['contraseña'] ?? '');

    if ($email === '' || $nombre === '' || $contraseña === '') {
        $error = 'Todos los campos son obligatorios';
        require __DIR__ . '/../views/usuarios/form.php';
        return;
    }

    try {
        Usuario::crear($pdo, $email, $nombre, $contraseña);
    } catch (PDOException $e) {
        $error = 'No se pudo crear el Usuario. Verificá que el email del usuario no esté repetido.';
        require __DIR__ . '/../views/usuarios/form.php';
        return;
    }

    header('Location: index.php?accion=listarUsuarios');
    exit;
}

function formEditarUsuario() {
    global $pdo;

    $usuario = Usuario::buscarPorId($pdo, $_GET['id'] ?? 0);

    if (!$usuario) {
        header('Location: index.php?accion=listarUsuarios');
        exit;
    }

    require __DIR__ . '/../views/usuarios/form.php';
}

function editarUsuario() {
    global $pdo;

    $id        = (int)($_POST['id'] ?? 0);
    $email = trim($_POST['email'] ?? '');
    $nombre    = trim($_POST['nombre'] ?? '');
    $contraseña   = trim($_POST['contraseña'] ?? '');

    $usuario = Usuario::buscarPorId($pdo, $id);

    if (!$usuario) {
        header('Location: index.php?accion=listarUsuarios');
        exit;
    }

    if ($email === '' || $nombre === '' || $contraseña === '') {
        $error = 'Todos los campos son obligatorios';
        require __DIR__ . '/../views/usuarios/form.php';
        return;
    }

    try {
        Usuario::actualizar($pdo, $id, $email, $nombre, $contraseña);
    } catch (PDOException $e) {
        $error = 'No se pudo actualizar el Usuario. Verificá que el email del usuario no esté repetido.';
        require __DIR__ . '/../views/usuarios/form.php';
        return;
    }

    header('Location: index.php?accion=listarUsuarios');
    exit;
}

function eliminarUsuario() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);

    try {
        Usuario::eliminar($pdo, $id);
    } catch (PDOException $e) {
        $usuarios = Usuario::listar($pdo);
        require __DIR__ . '/../views/usuarios/listar.php';
        return;
    }

    header('Location: index.php?accion=listarUsuarios');
    exit;
}
