<?php
require_once __DIR__ . '/../models/Prestamo.php';
require_once __DIR__ . '/../models/Socio.php';
require_once __DIR__ . '/../models/Libro.php';
require_once __DIR__ . '/../conexion.php';

function listarPrestamos() {
    global $pdo;
    $prestamos = Prestamo::listar($pdo);
    require __DIR__ . '/../views/prestamos/listar.php';
}

function formCrearPrestamo() {
    global $pdo;

    $Socios=Socio::listar($pdo);
    $Libros=Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function crearPrestamo() {
    global $pdo;

    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? '');

    if ($socioId === '' || $libroId === '' || $fechaPrestamo === '') {
        $error = 'Todos los campos son obligatorios.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el socio exista antes de crear el préstamo
    $stmt = $pdo->prepare('SELECT id FROM socios WHERE id = ?');
    $stmt->execute([(int)$socioId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El socio seleccionado no existe.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el libro exista antes de crear el préstamo
    $stmt = $pdo->prepare('SELECT id FROM libros WHERE id = ?');
    $stmt->execute([(int)$libroId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El libro seleccionado no existe.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    try {
        Prestamo::crear($pdo, (int)$socioId, (int)$libroId, $fechaPrestamo);
    } catch (InvalidArgumentException $e) {
        $error = $e->getMessage();
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    } catch (PDOException $e) {
        $error = 'No se pudo crear el préstamo porque la clave foránea de la base de datos no coincide con el socio o libro seleccionado.';
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}


function formEditarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    $prestamo = Prestamo::buscar($pdo, $id);

    if (!$prestamo) {
        header('Location: index.php?accion=listarPrestamos');
        exit;
    }

    $Socios = Socio::listar($pdo);
    $Libros = Libro::listar($pdo);
    require __DIR__ . '/../views/prestamos/form.php';
}

function editarPrestamo() {
    global $pdo;

    $id = (int)($_POST['id'] ?? 0);
    $socioId = trim($_POST['socioId'] ?? '');
    $libroId = trim($_POST['libroId'] ?? '');
    $fechaPrestamo = trim($_POST['fechaPrestamo'] ?? '');

    if ($id <= 0 || $socioId === '' || $libroId === '' || $fechaPrestamo === '') {
        $error = 'Todos los campos son obligatorios.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el socio exista antes de editar el préstamo
    $stmt = $pdo->prepare('SELECT id FROM socios WHERE id = ?');
    $stmt->execute([(int)$socioId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El socio seleccionado no existe.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    // Verificar que el libro exista antes de editar el préstamo
    $stmt = $pdo->prepare('SELECT id FROM libros WHERE id = ?');
    $stmt->execute([(int)$libroId]);
    if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
        $error = 'El libro seleccionado no existe.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    try {
        Prestamo::editar($pdo, $id, (int)$socioId, (int)$libroId, $fechaPrestamo);
    } catch (PDOException $e) {
        $error = 'No se pudo editar el préstamo porque la clave foránea de la base de datos no coincide con el socio o libro seleccionado.';
        $prestamo = Prestamo::buscar($pdo, $id);
        $Socios = Socio::listar($pdo);
        $Libros = Libro::listar($pdo);
        require __DIR__ . '/../views/prestamos/form.php';
        return;
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}

function eliminarPrestamo() {
    global $pdo;

    $id = (int)($_GET['id'] ?? 0);
    if ($id > 0) {
        Prestamo::eliminar($pdo, $id);
    }

    header('Location: index.php?accion=listarPrestamos');
    exit;
}
