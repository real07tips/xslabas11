<?php
require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../conexion.php';

function formLogin() {
    require __DIR__ . '/../login.php';
}

function login() {
    global $pdo;

    $email = trim($_POST['email'] ?? '');
    $contrasena = $_POST['contrasena'] ?? '';

    Usuario::buscarPorEmail($pdo, $email);

  
}

function logout() {
    session_destroy();
    header('Location: index.php?accion=login');
    exit;
}